from django.contrib import admin
from django.urls import path
from analytics import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", views.home, name="home"),
    path("preprocessing/", views.preprocessing, name="preprocessing"),
    path("results/", views.dashboard, name="dashboard"),
    # Keep the old address working for anyone who bookmarked it.
    path("dashboard/", views.dashboard, name="dashboard_legacy"),
    path("reset/", views.reset_dataset, name="reset_dataset"),
]
