# Presentation Guide — Data Analysis Project

## Before the presentation

1. Double-click `START_DATA_ANALYSIS_PROJECT.bat`.
2. The website opens at `http://127.0.0.1:8000`.
3. Keep the server window open while using the website.

## Suggested presentation flow

1. **Upload & Select:** Explain how the user uploads a CSV/XLSX dataset and selects the target column.
2. **Data Preprocessing:** Show missing-value counts and imputation, IQR outlier treatment, duplicate removal, identifier/empty-column handling, scaling and categorical encoding.
3. **EDA & Results:** Explain the feature distributions, box plot, scatter plot, correlation heatmap and feature importance chart.
4. **Model Evaluation:** Explain the metrics shown for the trained Random Forest classifier or regressor.
5. **Prediction:** Enter sample feature values and show the generated prediction.

## Notes

- Use the real dataset that you intend to describe in your report and cite its source.
- Explain that evaluation scores depend on the target column, data quality and train/test split.
- Do not upload private personal information.
- This project is intended for local academic use, not as a production decision system.
