@echo off
setlocal
cd /d "%~dp0"
title Data Analysis Project - One-Click Launcher

 echo ============================================================
 echo   DATA ANALYSIS PROJECT - DATA MINING AND MACHINE LEARNING PROJECT
 echo ============================================================
 echo.

REM Create the virtual environment only if it is missing.
if not exist ".venv\Scripts\python.exe" (
    echo First-time setup: creating the local Python environment...
    where py >nul 2>&1
    if errorlevel 1 (
        echo Python Launcher "py" was not found. Please install Python and try again.
        echo During Python installation, enable the option to add Python to PATH.
        pause
        exit /b 1
    )
    py -m venv .venv
    if errorlevel 1 (
        echo Could not create the Python environment.
        pause
        exit /b 1
    )
)

REM Install packages only if the environment is missing required imports.
".venv\Scripts\python.exe" -c "import django, pandas, numpy, sklearn, plotly, openpyxl" >nul 2>&1
if errorlevel 1 (
    echo First-time setup: installing required packages. This may take a while.
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 (
        echo.
        echo Package installation failed. Check your internet connection and try again.
        pause
        exit /b 1
    )
)

echo Checking the local database...
".venv\Scripts\python.exe" manage.py migrate
if errorlevel 1 (
    echo.
    echo Database setup failed. Read the error above.
    pause
    exit /b 1
)

echo.
echo Starting Data Analysis Project at http://127.0.0.1:8000 ...
start "Data Analysis Project Django Server" /D "%~dp0" "%~dp0.venv\Scripts\python.exe" manage.py runserver 127.0.0.1:8000

echo Waiting for Django to start...
timeout /t 4 /nobreak >nul
start "" "http://127.0.0.1:8000"
echo.
echo Data Analysis Project should now be open in your browser.
echo Keep the server window open while using the website.
echo To stop Data Analysis Project, click the server window and press Ctrl+C.
echo.
exit /b 0
