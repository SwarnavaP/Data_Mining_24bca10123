(function () {
  const fileInput = document.getElementById('dataset-file');
  const dropZone = document.querySelector('.drop-zone');
  const fileName = document.getElementById('file-name');
  const fileHelp = document.getElementById('file-help');

  if (!fileInput || !dropZone) return;

  function updateFile(file) {
    if (!file) return;
    fileName.textContent = file.name;
    const sizeMb = (file.size / (1024 * 1024)).toFixed(2);
    fileHelp.textContent = `${sizeMb} MB · Ready to upload`;
    dropZone.classList.remove('dragover');
  }

  fileInput.addEventListener('change', function () {
    updateFile(fileInput.files && fileInput.files[0]);
  });

  ['dragenter', 'dragover'].forEach(function (eventName) {
    dropZone.addEventListener(eventName, function (event) {
      event.preventDefault();
      dropZone.classList.add('dragover');
    });
  });
  ['dragleave', 'drop'].forEach(function (eventName) {
    dropZone.addEventListener(eventName, function (event) {
      event.preventDefault();
      dropZone.classList.remove('dragover');
    });
  });
  dropZone.addEventListener('drop', function (event) {
    const files = event.dataTransfer && event.dataTransfer.files;
    if (!files || !files.length) return;
    const file = files[0];
    const extension = file.name.toLowerCase().split('.').pop();
    if (!['csv', 'xlsx'].includes(extension)) {
      fileName.textContent = 'Please choose a CSV or XLSX file';
      fileHelp.textContent = 'Unsupported file type';
      return;
    }
    try {
      const transfer = new DataTransfer();
      transfer.items.add(file);
      fileInput.files = transfer.files;
      updateFile(file);
    } catch (error) {
      // Browsers that restrict programmatic file assignment can still use Browse.
      fileName.textContent = file.name;
      fileHelp.textContent = 'Use Browse if the file was not attached automatically';
    }
  });
})();
