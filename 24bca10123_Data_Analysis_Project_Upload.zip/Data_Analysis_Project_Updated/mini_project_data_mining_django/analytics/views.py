"""Django views for upload, analysis dashboard, and interactive prediction."""
from __future__ import annotations

import hashlib
from pathlib import Path
from uuid import uuid4

import pandas as pd
from django.conf import settings
from django.core.cache import cache
from django.contrib import messages
from django.shortcuts import redirect, render

from .pipeline import build_report, guess_target_column, make_prediction

ALLOWED_EXTENSIONS = {".csv", ".xlsx"}
MAX_UPLOAD_BYTES = 15 * 1024 * 1024


def _read_dataset(path: Path) -> pd.DataFrame:
    extension = path.suffix.lower()
    if extension == ".csv":
        try:
            return pd.read_csv(path, low_memory=False, encoding="utf-8-sig")
        except UnicodeDecodeError:
            return pd.read_csv(path, low_memory=False, encoding="latin-1")
    if extension == ".xlsx":
        return pd.read_excel(path, engine="openpyxl")
    raise ValueError("Only CSV and XLSX files are supported.")


def _safe_session_path(request) -> Path | None:
    relative_path = request.session.get("dataset_rel")
    if not relative_path:
        return None
    candidate = (settings.BASE_DIR / str(relative_path)).resolve()
    allowed_roots = [
        (settings.BASE_DIR / "data").resolve(),
        (settings.MEDIA_ROOT / "uploads").resolve(),
    ]
    allowed = any(candidate == root or root in candidate.parents for root in allowed_roots)
    if not allowed or not candidate.is_file():
        return None
    return candidate


def _cache_key(path: Path, target: str) -> str:
    stat = path.stat()
    raw = f"{path.resolve()}|{stat.st_size}|{stat.st_mtime_ns}|{target}".encode("utf-8")
    return "analysis-" + hashlib.sha256(raw).hexdigest()


def home(request):
    if request.method == "POST":
        uploaded_file = request.FILES.get("dataset_file")
        target_column = request.POST.get("target_column", "").strip()
        if not uploaded_file:
            messages.error(request, "Choose a CSV or XLSX dataset to upload.")
            return redirect("home")
        extension = Path(uploaded_file.name).suffix.lower()
        if extension not in ALLOWED_EXTENSIONS:
            messages.error(request, "Unsupported file type. Upload a .csv or .xlsx file.")
            return redirect("home")
        if uploaded_file.size > MAX_UPLOAD_BYTES:
            messages.error(request, "The file exceeds the 15 MB upload limit. Please use a smaller dataset.")
            return redirect("home")

        upload_dir = settings.MEDIA_ROOT / "uploads"
        upload_dir.mkdir(parents=True, exist_ok=True)
        clean_name = Path(uploaded_file.name).name.replace(" ", "_")
        stored_name = f"{uuid4().hex}_{clean_name}"
        destination = upload_dir / stored_name
        try:
            with destination.open("wb") as output:
                for chunk in uploaded_file.chunks():
                    output.write(chunk)
            if not target_column:
                headers = _read_dataset(destination).columns
                target_column = guess_target_column(headers)
            if not target_column:
                destination.unlink(missing_ok=True)
                messages.error(
                    request,
                    "Enter the target column to predict (for example, Churn, Outcome, or Loan_Status). "
                    "The app could not infer one from this file.",
                )
                return redirect("home")
        except Exception as exc:
            destination.unlink(missing_ok=True)
            messages.error(request, f"The file could not be read: {exc}")
            return redirect("home")

        request.session["dataset_rel"] = f"media/uploads/{stored_name}"
        request.session["target_column"] = target_column
        request.session["dataset_label"] = uploaded_file.name
        return redirect("preprocessing")

    return render(request, "home.html", {
        "target_default": request.session.get("target_column", "Churn"),
        "current_dataset": request.session.get("dataset_label", ""),
    })


def _get_current_report(request):
    """Return the selected dataset and its cached analysis report."""
    dataset_path = _safe_session_path(request)
    if dataset_path is None:
        messages.info(request, "Upload a dataset and choose its target column to begin.")
        return None

    target = str(request.session.get("target_column", "Churn"))
    cache_key = _cache_key(dataset_path, target)
    report = cache.get(cache_key)
    if report is None:
        try:
            raw_frame = _read_dataset(dataset_path)
            report = build_report(raw_frame, target)
            cache.set(cache_key, report, timeout=1800)
        except Exception as exc:
            messages.error(request, f"Analysis could not be completed: {exc}")
            return None
    return dataset_path, report


def preprocessing(request):
    loaded = _get_current_report(request)
    if loaded is None:
        return redirect("home")
    dataset_path, report = loaded
    return render(request, "preprocessing.html", {
        "report": report,
        "dataset_label": request.session.get("dataset_label", dataset_path.name),
    })


def dashboard(request):
    loaded = _get_current_report(request)
    if loaded is None:
        return redirect("home")
    dataset_path, report = loaded

    prediction_result = None
    prediction_error = None
    submitted_values = {}
    if request.method == "POST" and request.POST.get("action") == "predict":
        submitted_values = {field["name"]: request.POST.get(field["name"], "") for field in report["feature_fields"]}
        try:
            prediction_result = make_prediction(report, submitted_values)
        except Exception as exc:
            prediction_error = str(exc)

    context = {
        "report": report,
        "dataset_label": request.session.get("dataset_label", dataset_path.name),
        "prediction_result": prediction_result,
        "prediction_error": prediction_error,
        "form_values": submitted_values,
    }
    return render(request, "dashboard.html", context)


def reset_dataset(request):
    for key in ("dataset_rel", "target_column", "dataset_label"):
        request.session.pop(key, None)
    messages.success(request, "Dataset selection cleared. Upload another file to start a new analysis.")
    return redirect("home")
