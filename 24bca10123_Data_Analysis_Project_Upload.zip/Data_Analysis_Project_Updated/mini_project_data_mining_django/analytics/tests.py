from pathlib import Path

import pandas as pd
from django.test import SimpleTestCase

from .pipeline import build_report, make_prediction


class DataMiningPipelineTests(SimpleTestCase):
    def setUp(self):
        project_root = Path(__file__).resolve().parent.parent
        self.frame = pd.read_csv(project_root / "data" / "sample_customer_churn.csv")

    def test_churn_dataset_builds_classification_report(self):
        report = build_report(self.frame, "Churn")
        self.assertEqual(report["task"], "classification")
        self.assertIn("accuracy", report["metrics_raw"])
        self.assertIn("confusion", report["charts"])
        self.assertEqual(report["missing_after_total"], 0)
        self.assertGreater(report["records_clean"], 500)

    def test_default_feature_values_produce_a_prediction(self):
        report = build_report(self.frame, "Churn")
        values = {field["name"]: str(field["default"]) for field in report["feature_fields"]}
        result = make_prediction(report, values)
        self.assertIn(result["value"], {"Yes", "No"})
        self.assertIsNotNone(result["confidence"])
