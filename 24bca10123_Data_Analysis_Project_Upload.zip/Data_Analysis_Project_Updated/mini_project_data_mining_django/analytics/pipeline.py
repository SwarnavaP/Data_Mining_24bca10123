"""Reusable data-cleaning, EDA, preprocessing, modelling, and prediction logic."""
from __future__ import annotations

import html
import re
from typing import Any

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
    precision_score,
    r2_score,
    recall_score,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


TARGET_CANDIDATES = [
    "churn", "target", "outcome", "label", "class", "loan_status",
    "loan_status_label", "approval_status", "heart_disease", "disease",
    "survived", "default", "price", "saleprice", "median_house_value",
]
ID_EXACT_NAMES = {
    "id", "customerid", "customer_id", "userid", "user_id", "recordid",
    "record_id", "row_id", "rowid", "index", "uuid", "customer_uuid",
    "subscriberid", "accountid", "memberid", "unnamed: 0", "unnamed:0",
}


class IQRClipper(BaseEstimator, TransformerMixin):
    """Clip numeric outliers to training-set IQR fences.

    The transformer is placed inside the sklearn pipeline, so the bounds are
    learned from the training partition and reused for validation/predictions.
    """

    def fit(self, X, y=None):
        values = np.asarray(X, dtype=float)
        q1 = np.nanpercentile(values, 25, axis=0)
        q3 = np.nanpercentile(values, 75, axis=0)
        iqr = q3 - q1
        self.lower_bounds_ = q1 - 1.5 * iqr
        self.upper_bounds_ = q3 + 1.5 * iqr
        return self

    def transform(self, X):
        values = np.asarray(X, dtype=float)
        return np.clip(values, self.lower_bounds_, self.upper_bounds_)

    def get_feature_names_out(self, input_features=None):
        # Outlier clipping changes values, not the feature names.
        if input_features is None:
            return np.asarray([f"x{i}" for i in range(len(self.lower_bounds_))], dtype=object)
        return np.asarray(input_features, dtype=object)



def guess_target_column(columns) -> str:
    lookup = {str(column).strip().lower(): str(column) for column in columns}
    for candidate in TARGET_CANDIDATES:
        if candidate in lookup:
            return lookup[candidate]
    return ""


def _unique_column_names(columns) -> list[str]:
    seen: dict[str, int] = {}
    result = []
    for raw_name in columns:
        name = str(raw_name).strip() or "unnamed_column"
        count = seen.get(name, 0)
        seen[name] = count + 1
        result.append(name if count == 0 else f"{name}_{count + 1}")
    return result


def _is_identifier(column: str) -> bool:
    cleaned = re.sub(r"\s+", "", str(column).strip().lower())
    return (
        cleaned in ID_EXACT_NAMES
        or cleaned.endswith(("_id", "_uuid", "_key"))
        or cleaned.startswith("unnamed:")
    )


def _load_and_clean(frame: pd.DataFrame, target_column: str):
    """Clean headers, null tokens, duplicates, numeric-like strings and IDs."""
    raw_rows = len(frame)
    original_columns = list(frame.columns)
    df = frame.copy()
    df.columns = _unique_column_names(df.columns)

    # Blank strings and common missing-value sentinels become real NaN values.
    df = df.replace(r"^\s*$", np.nan, regex=True)
    for column in df.select_dtypes(include=["object", "string"]).columns:
        df[column] = df[column].map(lambda value: value.strip() if isinstance(value, str) else value)
    df = df.replace({"?": np.nan, "NA": np.nan, "N/A": np.nan, "null": np.nan, "None": np.nan})
    empty_columns = [column for column in df.columns if df[column].isna().all()]
    if empty_columns:
        df = df.drop(columns=empty_columns)

    duplicate_count = int(df.duplicated().sum())
    df = df.drop_duplicates().copy()

    # Resolve target column case-insensitively.
    target_requested = str(target_column or "").strip()
    name_lookup = {str(column).lower(): str(column) for column in df.columns}
    actual_target = name_lookup.get(target_requested.lower(), "")
    if not actual_target:
        suggestion = guess_target_column(df.columns)
        if suggestion:
            raise ValueError(
                f"Target column '{target_requested}' was not found. This file appears to contain "
                f"'{suggestion}'. Enter that exact column name in the upload form."
            )
        raise ValueError(
            f"Target column '{target_requested}' was not found. Check the CSV/XLSX header and "
            "enter the column you want the model to predict."
        )

    # Convert numeric-looking text (such as Telco TotalCharges) to numbers.
    for column in df.select_dtypes(include=["object", "string"]).columns:
        if column == actual_target:
            candidate = pd.to_numeric(df[column], errors="coerce")
            denominator = int(df[column].notna().sum())
            if denominator and candidate.notna().sum() / denominator >= 0.90:
                df[column] = candidate
            continue
        candidate = pd.to_numeric(df[column], errors="coerce")
        denominator = int(df[column].notna().sum())
        if denominator and candidate.notna().sum() / denominator >= 0.85:
            df[column] = candidate

    missing_before_target_filter = int(df[actual_target].isna().sum())
    df = df.dropna(subset=[actual_target]).copy()
    if df.empty:
        raise ValueError("No rows remain after removing records with a missing target value.")

    # A feature may become entirely empty after target-missing rows are removed.
    empty_after_target_filter = [
        column for column in df.columns
        if column != actual_target and df[column].isna().all()
    ]
    if empty_after_target_filter:
        df = df.drop(columns=empty_after_target_filter)
        empty_columns.extend(column for column in empty_after_target_filter if column not in empty_columns)

    identifier_columns = [column for column in df.columns if column != actual_target and _is_identifier(column)]
    feature_columns = [
        column for column in df.columns
        if column != actual_target and column not in identifier_columns
    ]
    if not feature_columns:
        raise ValueError("No usable predictor columns remain after removing the target and identifier fields.")

    X = df[feature_columns].copy()
    y = df[actual_target].copy()
    if y.nunique(dropna=True) < 2:
        raise ValueError("The target column must contain at least two different values to train a model.")
    if len(df) < 20:
        raise ValueError("At least 20 usable rows are required for a train/test split. Add more data and retry.")

    missing_before_imputation = X.isna().sum().astype(int).to_dict()
    numeric_columns = list(X.select_dtypes(include=[np.number]).columns)
    categorical_columns = [column for column in feature_columns if column not in numeric_columns]

    # Prepare a display/EDA copy. Model preprocessing is fitted independently
    # inside the train/test pipeline to avoid validation leakage.
    X_display = X.copy()
    outlier_counts: dict[str, int] = {}
    for column in numeric_columns:
        valid = pd.to_numeric(X_display[column], errors="coerce")
        median = valid.median()
        if pd.isna(median):
            median = 0.0
        q1 = valid.quantile(0.25)
        q3 = valid.quantile(0.75)
        if pd.isna(q1) or pd.isna(q3):
            lower, upper = -np.inf, np.inf
        else:
            spread = q3 - q1
            lower, upper = q1 - 1.5 * spread, q3 + 1.5 * spread
        outlier_counts[column] = int(((valid < lower) | (valid > upper)).sum())
        X_display[column] = valid.fillna(median).clip(lower=lower, upper=upper)

    for column in categorical_columns:
        mode = X_display[column].mode(dropna=True)
        fill_value = mode.iloc[0] if not mode.empty else "Unknown"
        X_display[column] = X_display[column].fillna(fill_value).astype(str)

    processed_df = X_display.copy()
    processed_df[actual_target] = y.values
    missing_after_processing = processed_df.isna().sum().astype(int).to_dict()

    return {
        "data": df,
        "X": X,
        "X_display": X_display,
        "y": y,
        "target": actual_target,
        "feature_columns": feature_columns,
        "numeric_columns": numeric_columns,
        "categorical_columns": categorical_columns,
        "identifier_columns": identifier_columns,
        "empty_columns": empty_columns,
        "duplicates_removed": duplicate_count,
        "rows_missing_target_removed": missing_before_target_filter,
        "input_rows": raw_rows,
        "input_column_count": len(original_columns),
        "missing_before": missing_before_imputation,
        "missing_after": missing_after_processing,
        "outlier_counts": outlier_counts,
        "processed_df": processed_df,
    }


def _plot_html(fig, include_js=False) -> str:
    return fig.to_html(
        full_html=False,
        include_plotlyjs="cdn" if include_js else False,
        config={"displaylogo": False, "responsive": True},
    )


def _chart_layout(fig, height=330):
    fig.update_layout(
        template="plotly_white",
        height=height,
        margin=dict(l=22, r=18, t=60, b=36),
        font=dict(family="Arial, sans-serif", size=12, color="#233044"),
        title=dict(x=0.02, xanchor="left", font=dict(size=16)),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
    )
    return fig


def _safe_label(value: Any) -> str:
    return html.escape(str(value))


def _build_charts(cleaned: dict, metrics: dict, model=None, task=None) -> dict[str, str]:
    charts: dict[str, str] = {}
    include_js_next = True

    def add(name, fig):
        nonlocal include_js_next
        charts[name] = _plot_html(_chart_layout(fig), include_js=include_js_next)
        include_js_next = False

    target = cleaned["target"]
    frame = cleaned["processed_df"]
    X_display = cleaned["X_display"]
    numeric = cleaned["numeric_columns"]

    # Target distribution.
    target_counts = frame[target].astype(str).value_counts(dropna=False).rename_axis("target_value").reset_index(name="records")
    target_counts["target_value"] = target_counts["target_value"].map(_safe_label)
    add("target", px.bar(
        target_counts, x="target_value", y="records", text="records",
        title=f"Target distribution — {_safe_label(target)}",
        labels={"target_value": "Target value", "records": "Records"},
    ).update_traces(textposition="outside", marker_color="#4378d0"))

    if numeric:
        distribution_col = numeric[0]
        add("distribution", px.histogram(
            X_display, x=distribution_col, nbins=28,
            title=f"Feature distribution — {_safe_label(distribution_col)}",
            labels={distribution_col: _safe_label(distribution_col), "count": "Records"},
            color_discrete_sequence=["#1a9b8a"],
        ))

        box_columns = numeric[:6]
        long_numeric = X_display[box_columns].melt(var_name="feature", value_name="value")
        long_numeric["feature"] = long_numeric["feature"].map(_safe_label)
        add("box", px.box(
            long_numeric, x="feature", y="value", points="outliers",
            title="Numeric feature box plots (after IQR clipping)",
            labels={"feature": "Feature", "value": "Value"},
            color_discrete_sequence=["#f09b4a"],
        ))

        if len(numeric) >= 2:
            scatter_columns = numeric[:2]
            scatter_frame = X_display[scatter_columns].copy()
            scatter_frame[target] = cleaned["y"].astype(str).values
            if len(scatter_frame) > 1800:
                scatter_frame = scatter_frame.sample(1800, random_state=42)
            add("scatter", px.scatter(
                scatter_frame, x=scatter_columns[0], y=scatter_columns[1], color=target,
                title=f"Scatter plot — {_safe_label(scatter_columns[0])} vs {_safe_label(scatter_columns[1])}",
                labels={scatter_columns[0]: _safe_label(scatter_columns[0]), scatter_columns[1]: _safe_label(scatter_columns[1])},
                opacity=0.7,
            ))
        else:
            # A useful scatter plot remains available even with only one numeric feature.
            scatter_frame = X_display[[numeric[0]]].copy().reset_index(drop=True)
            scatter_frame["record_number"] = np.arange(1, len(scatter_frame) + 1)
            scatter_frame[target] = cleaned["y"].astype(str).values
            add("scatter", px.scatter(
                scatter_frame.sample(min(1800, len(scatter_frame)), random_state=42),
                x="record_number", y=numeric[0], color=target,
                title=f"Records vs {_safe_label(numeric[0])}",
                labels={"record_number": "Record number", numeric[0]: _safe_label(numeric[0])},
                opacity=0.7,
            ))

        corr_columns = numeric[:12]
        corr = X_display[corr_columns].corr(numeric_only=True)
        if not corr.empty:
            corr.index = [_safe_label(item) for item in corr.index]
            corr.columns = [_safe_label(item) for item in corr.columns]
            add("correlation", px.imshow(
                corr, text_auto=".2f", aspect="auto", color_continuous_scale="RdBu_r",
                zmin=-1, zmax=1, title="Correlation heatmap (numeric features)",
            ))

    if model is not None:
        try:
            estimator = model.named_steps["model"]
            importance = estimator.feature_importances_
            names = model.named_steps["preprocessor"].get_feature_names_out()
            importance_df = pd.DataFrame({"feature": names, "importance": importance})
            importance_df["feature"] = importance_df["feature"].astype(str).map(
                lambda value: _safe_label(value.replace("numeric__", "").replace("categorical__", ""))
            )
            importance_df = importance_df.nlargest(12, "importance").sort_values("importance")
            add("importance", px.bar(
                importance_df, x="importance", y="feature", orientation="h",
                title="Feature importance — top predictors",
                labels={"importance": "Importance", "feature": "Feature"},
                color="importance", color_continuous_scale="Tealgrn",
            ))
        except Exception:
            pass

    if metrics.get("confusion_matrix") is not None:
        matrix = metrics["confusion_matrix"]
        labels = metrics["class_labels"]
        matrix_frame = pd.DataFrame(matrix, index=labels, columns=labels)
        matrix_frame.index = [_safe_label(value) for value in matrix_frame.index]
        matrix_frame.columns = [_safe_label(value) for value in matrix_frame.columns]
        add("confusion", px.imshow(
            matrix_frame, text_auto=True, aspect="auto", color_continuous_scale="Blues",
            labels={"x": "Predicted class", "y": "Actual class", "color": "Count"},
            title="Confusion matrix",
        ))

    return charts


def build_report(raw_frame: pd.DataFrame, target_column: str) -> dict:
    """Create cleaned previews, EDA charts, train a model, and return dashboard data."""
    cleaned = _load_and_clean(raw_frame, target_column)
    X = cleaned["X"]
    y = cleaned["y"]
    numeric_columns = cleaned["numeric_columns"]
    categorical_columns = cleaned["categorical_columns"]

    is_numeric_target = pd.api.types.is_numeric_dtype(y)
    distinct_targets = int(y.nunique(dropna=True))
    if not is_numeric_target or distinct_targets <= 20:
        task = "classification"
        if distinct_targets > 50:
            raise ValueError(
                f"The selected target has {distinct_targets} distinct labels, which is too many for this "
                "classification mini-project. Select a more suitable target column."
            )
        model_estimator = RandomForestClassifier(
            n_estimators=160,
            random_state=42,
            class_weight="balanced_subsample",
            n_jobs=-1,
        )
    else:
        task = "regression"
        y = pd.to_numeric(y, errors="coerce")
        valid_rows = y.notna()
        X = X.loc[valid_rows].copy()
        y = y.loc[valid_rows].copy()
        if len(y) < 20:
            raise ValueError("The target must be numeric for regression and have at least 20 valid rows.")
        model_estimator = RandomForestRegressor(n_estimators=160, random_state=42, n_jobs=-1)

    if not numeric_columns and not categorical_columns:
        raise ValueError("No usable features were found after cleaning the dataset.")

    numeric_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("iqr_clip", IQRClipper()),
        ("scaler", StandardScaler()),
    ])
    categorical_pipeline = Pipeline([
        ("imputer", SimpleImputer(strategy="most_frequent")),
        ("onehot", OneHotEncoder(handle_unknown="ignore")),
    ])
    transformers = []
    if numeric_columns:
        transformers.append(("numeric", numeric_pipeline, numeric_columns))
    if categorical_columns:
        transformers.append(("categorical", categorical_pipeline, categorical_columns))
    preprocessor = ColumnTransformer(transformers=transformers, remainder="drop")
    model = Pipeline([
        ("preprocessor", preprocessor),
        ("model", model_estimator),
    ])

    stratify = None
    if task == "classification":
        counts = y.value_counts(dropna=False)
        if counts.min() >= 2 and counts.shape[0] <= 20:
            stratify = y
    try:
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.20, random_state=42, stratify=stratify
        )
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
    except Exception as exc:
        raise ValueError(
            "The model could not be trained on this file. Check for extremely rare target labels, "
            f"invalid data types, or too few usable rows. Technical detail: {exc}"
        ) from exc

    metrics: dict[str, Any] = {"confusion_matrix": None, "class_labels": []}
    if task == "classification":
        metrics.update({
            "accuracy": float(accuracy_score(y_test, predictions)),
            "precision": float(precision_score(y_test, predictions, average="weighted", zero_division=0)),
            "recall": float(recall_score(y_test, predictions, average="weighted", zero_division=0)),
            "f1": float(f1_score(y_test, predictions, average="weighted", zero_division=0)),
        })
        class_labels = list(model.named_steps["model"].classes_)
        cm = confusion_matrix(y_test, predictions, labels=class_labels)
        metrics["confusion_matrix"] = cm.tolist()
        metrics["class_labels"] = [str(label) for label in class_labels]
        metric_cards = [
            {"label": "Accuracy", "value": f"{metrics['accuracy'] * 100:.1f}%"},
            {"label": "Precision (weighted)", "value": f"{metrics['precision'] * 100:.1f}%"},
            {"label": "Recall (weighted)", "value": f"{metrics['recall'] * 100:.1f}%"},
            {"label": "F1-score (weighted)", "value": f"{metrics['f1'] * 100:.1f}%"},
        ]
    else:
        metrics.update({
            "rmse": float(np.sqrt(mean_squared_error(y_test, predictions))),
            "mae": float(mean_absolute_error(y_test, predictions)),
            "r2": float(r2_score(y_test, predictions)),
        })
        metric_cards = [
            {"label": "RMSE", "value": f"{metrics['rmse']:.3f}"},
            {"label": "MAE", "value": f"{metrics['mae']:.3f}"},
            {"label": "R² score", "value": f"{metrics['r2']:.3f}"},
        ]

    missing_summary = []
    for column in cleaned["feature_columns"] + [cleaned["target"]]:
        missing_summary.append({
            "column": column,
            "before": int(cleaned["missing_before"].get(column, 0)) if column != cleaned["target"] else int(raw_frame[column].isna().sum()) if column in raw_frame else 0,
            "after": int(cleaned["missing_after"].get(column, 0)),
        })
    missing_summary.sort(key=lambda item: item["before"], reverse=True)

    display_df = cleaned["processed_df"].copy()
    display_df = display_df.head(10).replace({np.nan: "—"})
    preview_columns = [str(column) for column in display_df.columns]
    preview_rows = []
    for _, row in display_df.iterrows():
        preview_rows.append({column: _cell_value(row[column]) for column in preview_columns})

    feature_fields = _make_prediction_fields(
        cleaned["X_display"], cleaned["feature_columns"], cleaned["numeric_columns"], cleaned["categorical_columns"]
    )

    charts = _build_charts(cleaned, metrics, model=model, task=task)
    report = {
        "target": cleaned["target"],
        "task": task,
        "records_input": cleaned["input_rows"],
        "records_clean": int(len(cleaned["data"])),
        "columns_input": cleaned["input_column_count"],
        "columns_model": int(len(cleaned["feature_columns"]) + 1),
        "duplicates_removed": cleaned["duplicates_removed"],
        "rows_missing_target_removed": cleaned["rows_missing_target_removed"],
        "identifier_columns": cleaned["identifier_columns"],
        "empty_columns": cleaned["empty_columns"],
        "numeric_count": len(cleaned["numeric_columns"]),
        "categorical_count": len(cleaned["categorical_columns"]),
        "outlier_total": int(sum(cleaned["outlier_counts"].values())),
        "outlier_counts": [{"column": name, "count": count} for name, count in cleaned["outlier_counts"].items() if count > 0],
        "missing_summary": missing_summary,
        "missing_before_total": int(sum(cleaned["missing_before"].values())),
        "missing_after_total": int(sum(cleaned["missing_after"].values())),
        "preview_columns": preview_columns,
        "preview_rows": preview_rows,
        "metrics": metric_cards,
        "task_label": "Classification" if task == "classification" else "Regression",
        "charts": charts,
        "feature_fields": feature_fields,
        "feature_columns": cleaned["feature_columns"],
        "model": model,
        "metrics_raw": metrics,
        "target_classes": [str(value) for value in getattr(model.named_steps["model"], "classes_", [])],
        "pipeline_steps": ["Duplicate/blank cleanup", "Median/mode imputation", "IQR outlier clipping", "Standard scaling", "One-hot encoding", "Random Forest"],
    }
    return report


def _cell_value(value: Any) -> str:
    if pd.isna(value):
        return "—"
    if isinstance(value, (float, np.floating)):
        return f"{float(value):.3f}" if abs(float(value)) < 1_000_000 else f"{float(value):.2e}"
    return str(value)


def _make_prediction_fields(X, feature_columns, numeric_columns, categorical_columns):
    fields = []
    for column in feature_columns:
        series = X[column]
        if column in numeric_columns:
            median = pd.to_numeric(series, errors="coerce").median()
            default_value = 0 if pd.isna(median) else round(float(median), 3)
            fields.append({
                "name": column,
                "kind": "number",
                "default": default_value,
                "options": [],
            })
        else:
            values = [value for value in series.dropna().astype(str).value_counts().index.tolist()[:60]]
            mode = series.dropna().astype(str).mode()
            default_value = mode.iloc[0] if not mode.empty else (values[0] if values else "Unknown")
            fields.append({
                "name": column,
                "kind": "category",
                "default": default_value,
                "options": values,
            })
    return fields


def make_prediction(report: dict, submitted_values: dict[str, str]) -> dict:
    """Validate raw form values, then predict using the trained sklearn pipeline."""
    parsed = {}
    for field in report["feature_fields"]:
        name = field["name"]
        raw_value = submitted_values.get(name, "")
        if field["kind"] == "number":
            try:
                parsed[name] = float(raw_value) if str(raw_value).strip() else float(field["default"])
            except (TypeError, ValueError) as exc:
                raise ValueError(f"'{name}' must be a number.") from exc
        else:
            parsed[name] = str(raw_value) if str(raw_value).strip() else str(field["default"])

    sample = pd.DataFrame([parsed], columns=report["feature_columns"])
    model = report["model"]
    prediction = model.predict(sample)[0]
    if isinstance(prediction, np.generic):
        prediction = prediction.item()

    result = {"value": str(prediction), "confidence": None, "probabilities": []}
    if report["task"] == "classification" and hasattr(model.named_steps["model"], "predict_proba"):
        probabilities = model.predict_proba(sample)[0]
        classes = model.named_steps["model"].classes_
        result["confidence"] = float(np.max(probabilities))
        result["probabilities"] = [
            {"label": str(label), "value": float(probability)}
            for label, probability in sorted(zip(classes, probabilities), key=lambda pair: pair[1], reverse=True)[:5]
        ]
    return result
