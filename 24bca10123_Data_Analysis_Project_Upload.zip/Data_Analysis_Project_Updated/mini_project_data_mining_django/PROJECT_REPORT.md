# Data Analysis Project: A Django-Based Data Mining and Machine Learning Portal

## 1. Abstract

Data Analysis Project is a web-based mini project that combines data mining and machine learning techniques with a Django interface. A user uploads a CSV or XLSX dataset, selects the target attribute, reviews cleaned data and missing-value counts, explores dynamically generated visualisations, trains a Random Forest model, and tests predictions using custom feature values. The workflow covers duplicate removal, irrelevant identifier exclusion, missing-value imputation, IQR-based outlier handling, numerical scaling, categorical encoding, feature importance, and standard model evaluation. The recommended real-world case study is IBM Telco Customer Churn, available through Kaggle. A small sample CSV is kept only as an automated-test fixture; the web interface requires the user to upload the dataset they want to analyze.

## 2. Problem statement

Analysing raw datasets often requires a sequence of separate tasks: cleaning inconsistent values, identifying missing records, exploring patterns, selecting a suitable model, evaluating predictions, and making the trained model available to users. Data Analysis Project brings these tasks into one small web application so that a learner can observe how the dataset changes and how a model is evaluated before making an individual prediction.

## 3. Objectives

1. Build a Django web interface for CSV and Excel dataset upload.
2. Apply common data-cleaning and data-preprocessing methods.
3. Generate visual summaries of target values, feature distributions, outliers, scatter relationships, and correlations.
4. Train an appropriate Random Forest classifier or regressor and evaluate it with standard metrics.
5. Provide an interactive prediction form that uses the same fitted preprocessing pipeline as model training.
6. Present processed records and a missing-value audit to improve the transparency of the workflow.

## 4. Scope

The application is designed for academic use and tabular datasets. It supports CSV and XLSX files up to 15 MB. The user supplies the target column. Classification is used for category/text targets and numeric targets with up to 20 distinct values; regression is used for high-cardinality numeric targets. The application is intended for local use and does not include user accounts, multi-tenant access control, model governance, or a production deployment pipeline.

## 5. Dataset selection

The recommended dataset is **IBM Telco Customer Churn**, commonly distributed through Kaggle. It includes numerical attributes such as tenure and charges, categorical attributes such as contract and payment method, and a binary `Churn` target. The dataset is suitable for a classification exercise because the target indicates whether a customer churned.

**Dataset link:** https://www.kaggle.com/datasets/blastchar/telco-customer-churn

The bundled `sample_customer_churn.csv` is a fictional software-test fixture, not an external real-world dataset. To report real-world findings, download the original Kaggle CSV, upload it through the interface, and cite that source in the submission.

## 6. System architecture

```mermaid
flowchart TD
    A[User selects CSV or XLSX] --> B[Django upload view]
    B --> C[Read and validate dataset]
    C --> D[Clean headers, null tokens and duplicates]
    D --> E[Split target from predictors]
    E --> F[Train/test split]
    F --> G[Preprocessing pipeline]
    G --> H[Random Forest model]
    H --> I[Evaluation metrics]
    E --> J[EDA and processed preview]
    I --> K[Dashboard and feature importance]
    J --> K
    K --> L[User enters feature values]
    L --> M[Same fitted pipeline predicts result]
```

## 7. Data preprocessing

### 7.1 Missing-value treatment

Blank strings and common missing-value tokens are converted to missing values. Rows whose target is missing are removed because the supervised model cannot learn a target label for those rows. Numeric predictor columns use median imputation; categorical predictor columns use most-frequent-value imputation. The dashboard displays the missing counts before and after processing.

### 7.2 Duplicate and irrelevant-field removal

Exact duplicate rows are removed. All-empty columns are discarded. Columns that look like row identifiers or customer IDs are excluded from the predictor features because they generally identify records instead of describing the underlying behaviour. The dashboard reports which identifier columns were excluded.

### 7.3 Outlier treatment

The interquartile range is calculated as `IQR = Q3 - Q1`. The conventional IQR fences are `Q1 - 1.5 × IQR` and `Q3 + 1.5 × IQR`. Values outside these limits are counted in the data-quality panel. The model pipeline learns its clipping bounds from the training partition and applies the same bounds to test data and custom predictions.

### 7.4 Data transformation

Numeric features are imputed, IQR-clipped, and standardised by `StandardScaler`. Categorical features are imputed and transformed using `OneHotEncoder(handle_unknown="ignore")`. This allows the model to work with mixed numerical and categorical input fields.

### 7.5 Feature selection

The dashboard provides a numerical correlation heatmap to inspect linear relationships among numeric features. After training, Random Forest feature importances are displayed to show which transformed features contributed most to the fitted ensemble. Importance scores are descriptive, not proof of causation.

## 8. Exploratory data analysis

The dashboard dynamically generates the following visualisations from the uploaded file:

- Target distribution bar chart.
- Histogram of a numeric feature.
- Box plots for numeric features after display-side IQR clipping.
- Scatter plot of two numeric features (or a numeric feature against record position when only one numeric feature exists).
- Correlation heatmap for up to 12 numeric features.
- Feature-importance chart and, for classification, a confusion matrix.

The first ten processed rows are also displayed in a scrollable table.

## 9. Model training and evaluation

The app uses an 80/20 train/test split with a fixed random seed for repeatability. A Random Forest classifier is trained for classification tasks; a Random Forest regressor is used for high-cardinality numeric targets. Both models include the preprocessing steps in a single scikit-learn `Pipeline`. This is important because custom inputs pass through the same imputation, outlier clipping, scaling, and encoding steps as training data.

For classification, the dashboard reports accuracy, weighted precision, weighted recall, weighted F1-score, and the confusion matrix. For regression, it reports root mean squared error (RMSE), mean absolute error (MAE), and R². Evaluation values depend on the dataset and split; the report should record the actual values displayed after running the selected Kaggle file rather than assuming a fixed score.

## 10. Application pages

### Upload and target-selection page

The first page accepts `.csv` and `.xlsx` files and asks for the target-column name. It enforces a file-size limit and validates the file extension. After upload, the user moves to the preprocessing page.

### Data preprocessing page

The second page presents missing-value counts before and after imputation, numeric outlier counts, duplicate and missing-target row counts, identifier-like and empty-column exclusions, transformation methods, and a preview of the first ten processed rows.

### EDA, evaluation and prediction page

The third page presents record/feature counts, model task, evaluation metrics, Plotly charts, correlation analysis, feature importance, and an interactive prediction form. The charts include distributions, box plots, scatter plots, a correlation heatmap and a confusion matrix for classification when applicable.

### Prediction section

Feature fields are created dynamically based on the selected dataset. Numeric predictors use numeric inputs, while categorical predictors use dropdowns based on observed values. The prediction result is shown together with class probabilities when the model supports probability estimates.

## 11. Technology stack

- **Python:** data manipulation and model pipeline.
- **Django:** routing, file uploads, server-rendered pages, and request handling.
- **Pandas / NumPy:** dataset reading, cleaning, summaries, and numeric operations.
- **Scikit-learn:** imputers, transformations, train/test split, Random Forest models, and metrics.
- **Plotly:** interactive charts.
- **HTML/CSS/JavaScript:** responsive user interface and upload feedback.

## 12. Installation and execution

From the project directory on Windows PowerShell:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install -r requirements.txt
py manage.py migrate
py manage.py runserver
```

Browse to `http://127.0.0.1:8000`. For the assessed run, upload the real Telco Customer Churn CSV from Kaggle and use `Churn` as the target column.

## 13. Testing checklist

1. Upload the selected CSV or XLSX dataset and enter its target-column name.
2. Confirm the processed preview contains no blank feature cells.
3. Confirm the missing-value table shows post-processing counts.
4. Check that distribution, box, scatter, and correlation visualisations render.
5. Confirm classification metrics and a confusion matrix are shown for the churn target.
6. Submit the default prediction values and confirm a prediction is displayed.
7. Upload the real Kaggle CSV and repeat the checks with the real file.
8. Try an invalid extension or a missing/wrong target column and verify that a useful error message appears.

## 14. Limitations and future enhancements

Current limitations include a 15 MB upload cap, one selected target per analysis, no persistent model registry, and no production authentication or access control. Chart rendering relies on Plotly's CDN script. Future improvements could add dataset download status, saved model versions, downloadable cleaning reports, user-managed feature selection, cross-validation, hyperparameter tuning, fairness checks, model explainability, and a production deployment configuration.

## 15. References

1. Kaggle, *Telco Customer Churn*: https://www.kaggle.com/datasets/blastchar/telco-customer-churn
2. OpenML, *telco-customer-churn* dataset metadata: https://www.openml.org/search?id=45568&sort=runs&type=data
3. Django documentation: https://docs.djangoproject.com/
4. pandas documentation: https://pandas.pydata.org/docs/
5. scikit-learn documentation: https://scikit-learn.org/stable/
6. Plotly Python documentation: https://plotly.com/python/
