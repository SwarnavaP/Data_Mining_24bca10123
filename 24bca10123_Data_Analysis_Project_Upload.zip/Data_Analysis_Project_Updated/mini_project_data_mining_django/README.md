# Data Analysis Project

A Django-based data mining and machine learning project. Upload a CSV or Excel dataset, choose a target column, review preprocessing, explore visualizations, evaluate a model, and test a prediction.

## Workflow

1. **Upload & Select** — upload a `.csv` or `.xlsx` file and enter the exact target column name.
2. **Data Preprocessing** — inspect missing values before and after imputation, outlier handling, duplicate removal, irrelevant-column exclusion, feature scaling and categorical encoding.
3. **EDA & Results** — view feature distributions, box plots, scatter plots, correlation heatmaps, feature importance, model metrics, and predictions.

## Techniques included

- Missing-value audit and imputation using median for numeric values and mode for categorical values.
- IQR-based outlier detection and clipping for numeric features.
- Removal of duplicate rows and exclusion of empty or identifier-like columns.
- StandardScaler for numeric features and One-Hot Encoding for categorical features.
- Correlation analysis and Random Forest feature importance.
- Exploratory charts, including target/feature distributions, box plots, scatter plots and correlation heatmaps.
- Random Forest classification or regression with appropriate evaluation metrics.
- Interactive prediction form using the trained pipeline.

## Run the project on Windows

The launcher uses the existing `.venv` in this project folder. It creates the environment and installs requirements only if they are missing.

1. Extract the project folder to a permanent location.
2. Double-click `START_DATA_ANALYSIS_PROJECT.bat`.
3. The browser opens at `http://127.0.0.1:8000`.
4. Keep the server window open while using the site. Press `Ctrl+C` in the server window to stop it.

If you need to install dependencies manually for the first time, open PowerShell in this folder and run:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe manage.py migrate
.\.venv\Scripts\python.exe manage.py runserver
```

## Dataset notes

The application accepts CSV and XLSX files up to 15 MB. Use a suitable target column. A public option is the [IBM Telco Customer Churn dataset on Kaggle](https://www.kaggle.com/datasets/blastchar/telco-customer-churn); its target column is commonly named `Churn`. Confirm the exact column heading in your downloaded file before uploading.

The `data/sample_customer_churn.csv` file is used for automated software tests only. It is not automatically loaded by the website and is not presented as an external dataset.

## Project files

- `analytics/views.py` — upload flow, preprocessing/results pages and prediction handling.
- `analytics/pipeline.py` — data cleaning, preprocessing, charts, model training and prediction.
- `templates/home.html` — upload and target-selection page.
- `templates/preprocessing.html` — cleaning and preprocessing audit.
- `templates/dashboard.html` — EDA, evaluation results and interactive prediction.
- `static/css/style.css` and `static/js/main.js` — interface styling and upload interaction.
- `PROJECT_REPORT.md` — project report content.

## Important limitations

This project is designed for local academic use and tabular datasets. Model metrics depend on the data, target selection and train/test split. Predictions may be inaccurate and should not be used alone for important real-world decisions.
