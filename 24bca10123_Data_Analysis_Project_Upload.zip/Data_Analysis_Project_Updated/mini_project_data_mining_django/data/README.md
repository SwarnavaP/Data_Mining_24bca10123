# Dataset folder

`sample_customer_churn.csv` is an internally bundled test fixture used by automated pipeline tests. The web interface does not automatically load this file; upload the dataset you want to analyze from the first page.

For a public real-world dataset, use the IBM Telco Customer Churn dataset available through Kaggle: https://www.kaggle.com/datasets/blastchar/telco-customer-churn

When using external data in an academic report, cite the original source and clearly identify the file that was analyzed.
