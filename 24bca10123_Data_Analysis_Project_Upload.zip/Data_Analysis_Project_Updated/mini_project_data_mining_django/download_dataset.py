"""Download the commonly used IBM Telco Customer Churn CSV dataset.

The public mirror is provided for convenience. If it is unavailable, download
from Kaggle manually and save the file at data/WA_Fn-UseC_-Telco-Customer-Churn.csv.
"""
from pathlib import Path
from urllib.request import Request, urlopen

DESTINATION = Path(__file__).resolve().parent / "data" / "WA_Fn-UseC_-Telco-Customer-Churn.csv"
SOURCES = [
    "https://raw.githubusercontent.com/SohelRaja/Customer-Churn-Analysis/master/Datasets/WA_Fn-UseC_-Telco-Customer-Churn.csv",
    "https://huggingface.co/spaces/Akhdan/telco-churn-predict/resolve/main/WA_Fn-UseC_-Telco-Customer-Churn.csv",
]


def main():
    DESTINATION.parent.mkdir(parents=True, exist_ok=True)
    for url in SOURCES:
        try:
            request = Request(url, headers={"User-Agent": "DataMiningDjangoMiniProject/1.0"})
            with urlopen(request, timeout=30) as response:
                content = response.read()
            if len(content) < 10_000 or b"customerID" not in content[:5000]:
                raise ValueError("The downloaded file did not look like the expected CSV.")
            DESTINATION.write_bytes(content)
            rows = content.count(b"\n") - 1
            print(f"Dataset saved to: {DESTINATION}")
            print(f"Approximate data records: {max(rows, 0):,}")
            print("Dataset source context: https://www.kaggle.com/datasets/blastchar/telco-customer-churn")
            return
        except Exception as exc:
            print(f"Could not download from {url}: {exc}")
    print("\nAutomatic download failed. Download the CSV from the Kaggle page below:")
    print("https://www.kaggle.com/datasets/blastchar/telco-customer-churn")
    print("Place the downloaded file at:")
    print(DESTINATION)
    raise SystemExit(1)


if __name__ == "__main__":
    main()
