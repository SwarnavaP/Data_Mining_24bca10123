@echo off
setlocal
if not exist .venv\Scripts\python.exe (
  echo Create the virtual environment and install requirements first.
  echo   py -m venv .venv
  echo   .venv\Scripts\python.exe -m pip install -r requirements.txt
  pause
  exit /b 1
)
.venv\Scripts\python.exe manage.py migrate
.venv\Scripts\python.exe manage.py runserver
